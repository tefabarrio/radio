/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Estefania Barrio
 */
public interface NewInterface {
    public boolean estado();
    public String estacionActual();
    public void cambiarFrecuencia();
    public void avanzar();
    public void guardar(int boton);
    public void onOff();   
}
