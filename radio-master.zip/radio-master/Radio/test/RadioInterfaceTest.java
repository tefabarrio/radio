/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author oscar
 */
public class RadioInterfaceTest {
    
    public RadioInterfaceTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of estado method, of class RadioInterface.
     */
    @Test
    public void testEstado() {
        System.out.println("estado");
        RadioInterface instance = new RadioInterface();
        boolean expResult = false;
        boolean result = instance.estado();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of estacionActual method, of class RadioInterface.
     */
    @Test
    public void testEstacionActual() {
        System.out.println("estacionActual");
        RadioInterface instance = new RadioInterface();
        String expResult = "";
        String result = instance.estacionActual();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cambiarFrecuencia method, of class RadioInterface.
     */
    @Test
    public void testCambiarFrecuencia() {
        System.out.println("cambiarFrecuencia");
        RadioInterface instance = new RadioInterface();
        instance.cambiarFrecuencia();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of avanzar method, of class RadioInterface.
     */
    @Test
    public void testAvanzar() {
        System.out.println("avanzar");
        RadioInterface instance = new RadioInterface();
        instance.avanzar();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of guardar method, of class RadioInterface.
     */
    @Test
    public void testGuardar() {
        System.out.println("guardar");
        int boton = 0;
        RadioInterface instance = new RadioInterface();
        instance.guardar(boton);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of onOff method, of class RadioInterface.
     */
    @Test
    public void testOnOff() {
        System.out.println("onOff");
        RadioInterface instance = new RadioInterface();
        instance.onOff();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of acambiarFrecuencia method, of class RadioInterface.
     */
    @Test
    public void testAcambiarFrecuencia() {
        System.out.println("acambiarFrecuencia");
        RadioInterface instance = new RadioInterface();
        instance.acambiarFrecuencia();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
