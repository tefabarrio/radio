/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * Esablecimiento de contrato o protocolo a cumplir en clase RadioN
 */
public class RadioInterface {
    public boolean estado(){return false;
}
    public String estacionActual(){return null;
}
    public void cambiarFrecuencia(){}
    public void avanzar(){}
    public void guardar(int boton){}
    public void onOff(){}
    public void acambiarFrecuencia(){}
    
    
    
}
